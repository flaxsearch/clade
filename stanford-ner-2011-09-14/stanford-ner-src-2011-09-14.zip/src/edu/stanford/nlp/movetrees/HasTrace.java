package edu.stanford.nlp.movetrees;

import edu.stanford.nlp.trees.Tree;

interface HasTrace {

  public Tree traceTo();

}
